from PIL import Image
import numpy as np
import random
import os
import matplotlib.pyplot as plt
#import requests


np.seterr(all = 'ignore')
class Neural_Net(object):
    def __init__(self):
        self.epochs=10
        self.instances=180
        self.input_layer_size=10800;
        self.output_layer_size=20;
        self.hidden_layer_size=500;
        self.alpha=0.001
        self.w1=np.random.randn(self.input_layer_size,self.hidden_layer_size)
        self.w2=np.random.randn(self.hidden_layer_size,self.output_layer_size)
        self.bias1=np.random.randn(1,self.hidden_layer_size)
        self.bias2=np.random.randn(1,self.output_layer_size)
        
        
    def forward(self,X):
        self.z1=np.dot(X,self.w1)+self.bias1
        self.a1=self.sigmoid(self.z1)
        self.z2=np.dot(self.a1,self.w2)+self.bias2
        y_predicted=self.softmax_func(self.z2)
        return y_predicted
    
    def sigmoid(self,z):
           #np.clip(z,-500,500)
           return 1/(1+np.exp(-z))
       
    def sigmoid_prime(self,z):   
        return self.sigmoid(z)*(1-self.sigmoid(z));
    
    
    def train(self,X,y):
        cost_plot=np.zeros([self.epochs])
        for epoch in range(0,self.epochs):
        #for ep in range(0,1):
            
            print("epoch: "+ "  "+str(epoch))
            mse=0.0
            for i in range(0,self.instances): 
                x1=np.zeros([1,self.input_layer_size])
                y1=np.zeros([1,self.output_layer_size])
                for j in range(0,self.input_layer_size):
                    x1[0][j]=X[i][j]
                for j in range(0,self.output_layer_size):
                    y1[0][j]=y[i][j]
                self.y_hat=self.forward(x1)
                cost=self.cost_func(y1)
                mse=mse+cost
                
                delta3=-(y1-self.y_hat)
                delta2=np.dot(delta3,self.w2.T)*self.sigmoid_prime(self.a1)
                dw2=np.dot(self.a1.T,delta3)
                dw1=np.dot(x1.T,delta2)
                db2=delta3
                db1=delta2
                self.w2=self.w2-self.alpha*dw2
                self.w1=self.w1-self.alpha*dw1
                self.bias1=self.bias1-((self.alpha)*(db1))
                self.bias2=self.bias2-((self.alpha)*(db2))
            print "error="+str(mse)
            cost_plot[epoch]=mse
        return cost_plot  
    
    
    
    def cost_func(self,y):
         #y_tmp=((-1)*((y)*(np.log(self.y_hat))+((1-y)*(np.log(1-self.y_hat)))))
         y_tmp=(y-self.y_hat)**2
         #return np.sum(y_tmp)/self.output_layer_size
         return np.sum(y_tmp)/(2*self.output_layer_size)
        
        
    def softmax_func(self,zz):
        """Compute softmax values for each sets of scores in zz."""
        e_x = np.exp(zz - np.max(zz))
        return e_x / e_x.sum()
     
       
    def leaky_relu(self,z):
        m,n=z.shape
        for i in range(0,m):
            for j in range(0,n):
                if z[i][j]<0:
                    z[i][j]=0.01*z[i][j]
        return z
    def leaky_reluu(self,z):
        zz=np.multiply(0.01,z)
        return np.maximum(z,zz)
    def tanh(self,z):
        return (np.exp(z)-np.exp(-z))/(np.exp(z)+np.exp(-z))



x_values=np.zeros([200,10800])
y_values=np.zeros([200,1])
base_path="final/"

#this is converting each image into grayscale values from a folder where the images are serially numbered

for i in range(1,21):
    eyeList=os.listdir(base_path+str(i)+"/")
    for j in range(0,10):
        #c=chr(ord('a')+j)
        full_path=base_path+str(i)+"/"+str(eyeList[j])
        img=Image.open(full_path).convert('L')
        new_img=img.resize((60,180))
        x_values[(i-1)*10+j]=np.array(new_img).reshape((1,10800))
        y_values[(i-1)*10+j][0]=i-1;

#this is converting the given output values into an output matrix that could be used for 
#neural net  i.e. m*1 type
y_values1=np.zeros([200,20])
for i in range(0,200):
    xxx=y_values[i][0]
    for j in range(0,20):
        if xxx==j:
            y_values1[i][j]=1                  
y_values=y_values1 

x_values1=x_values.T
#this is normalisation of data by taking mean and standard deviation

for i in range(0,10800):
    mean1=np.mean(x_values1[i])
    std1=np.std(x_values1[i])
    x_values1[i,:]-=mean1
    x_values1[i,:]/=std1
             
x_values=x_values1.T             


#the dataset has 200 images and we are randomly selecting 180 for training and 20 for testing

num=random.sample(range(200),20);
vis=np.zeros([200,1]);
for i in range(0,20):
   vis[num[i]]=1;## SEE HERE

     
x_train=np.zeros([180,10800]);
x_test=np.zeros([20,10800]);
y_test=np.zeros([20,20]);
y_train=np.zeros([180,20])
itrain=0;
itest=0;         

#dividing my dataset into training and testing datasets and corresponding output values also


for i in range(0,200):
    if(vis[i]==1):
        x_test[itest] =x_values[i];
        y_test[itest]=y_values[i];
        itest+=1;
    else:
        x_train[itrain]=x_values[i];
        y_train[itrain]=y_values[i];
        itrain+=1;
#creating object of the class
obj=Neural_Net()

'''print y_test[0]
xx=x_test[0]
print xx
y=obj.forward(xx)
print y'''


#cost_values will store the costfunction values for each iteration for every instance

cost_values=obj.train(x_train,y_train)        

#using against to plot the cost_values values
        
iterat=np.arange(obj.epochs)*obj.instances;
plt.plot(iterat,cost_values)

plt.show()     


#counting total postives and hence predicting accuracy
tp=0;
for i in range(0,180):
  xx=x_train[i];
  xx=np.array([xx])
  yy=y_train[i]
  yy=np.array([yy])
  ypredict=obj.forward(xx)
  ypredict11=ypredict.argmax(axis=1)
  if(yy[0][ypredict11]==1):
   tp+=1


print("tp here is ",tp)
acc=tp/180.0
print("accuracy is:",acc) 
