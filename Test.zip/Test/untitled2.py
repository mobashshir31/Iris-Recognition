# -*- coding: utf-8 -*-
"""
Created on Thu Nov 02 00:33:16 2017

@author: Sunny
"""
from PIL import Image
from iris_imgprocess import processImg
import cv2
import numpy as np

ip = "S1030L01.jpg"
dest="temp/tmp.jpg"
processImg(ip,dest)
#cv2.waitKey(0)
#cv2.destroyAllWindows()

img=Image.open(ip).convert('L')
new_img=img.resize((60,180))
x_values[0]=np.array(new_img).reshape((1,10800))
print x_values[0]
